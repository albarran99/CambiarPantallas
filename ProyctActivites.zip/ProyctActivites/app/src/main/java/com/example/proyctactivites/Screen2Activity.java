package com.example.proyctactivites;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Screen2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen2);
    }

    public void chanceScreen(View v) {
        Intent firtsScreen = new Intent(this, MainActivity.class);
        startActivity(firtsScreen);
    }
}